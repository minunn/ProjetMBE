const express=require('express');
const nodemailer = require("nodemailer");
const path = require('path')
const ejs = require('ejs')
var bodyParser = require('body-parser');
const app=express();

app.use(express.static(__dirname + '/public'))
app.set('views', path.join(__dirname, '/public'));

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());
var port = 3000;

//var smtpTransport = nodemailer.createTransport({
  //  service: "gmail",
    //host: "smtp.gmail.com",
    //auth: {
      //  user: "projetmbe@gmail.com",
       // pass: "4f45e4r71d58e4"
  //  }
//});

app.get('/',function(req,res){
    res.render('views/index.ejs');
    });

    app.get('/formulaire', function(req, res) {
        res.render('views/formulaire.ejs');
    });

    app.get('/tarifs', function(req, res) {
        res.render('views/tarif.ejs');
    });

    app.get('/historique', function(req, res) {
        res.render('views/Historiques.ejs');
    });

    app.get('/mentions-legales', function(req, res) {
        res.render('views/mentions.ejs');
    });

    app.get('/partenaires', function(req, res) {
        res.render('views/Partenaires.ejs');
    });

    app.get('/formulaireenvoye', function(req, res) {
        res.render('views/formulaireFait.ejs');
    });
    //app.use(express.static(path.join(__dirname, 'public')));
    //app.use(express.static(__dirname+'/public'));
    app.post('/send', function (req, res) {
        let transporter = nodemailer.createTransport({
            host: 'smtp.gmail.com',
            port: 465,
            secure: true,
            auth: {
                user: 'projetmbe@gmail.com',
                pass: '4f45e4r71d58e4'
            }
        });
      let mailOptions={
        from : `"Demande de contact" ${req.body.mail} `,
        to : 'projetmbe@gmail.com',
        subject : req.body.rubrique,
        text : 'hello ?',
        html:  `
        <p>Vous avez une nouvelle demande de contact :</p>
        <ul>  
          <li>Nom : ${req.body.nom}</li>
          <li>Prénom : ${req.body.prenom}</li>
          <li>Adresse : ${req.body.adresse}</li> 
          <li>Email : ${req.body.mail}</li>
          <li>Téléphone : ${req.body.phone}</li>
          <li>Message : <br> ${req.body.messageperso}</li>
      `
     } 
         console.log(mailOptions);

         transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                return console.log(error);
            }
            console.log('Message %s sent: %s', info.messageId, info.response);
                res.render('views/formulaireFait.ejs');
            });
        });
            app.listen(port, function(){
              console.log('Server is running at port: ',port);
            });