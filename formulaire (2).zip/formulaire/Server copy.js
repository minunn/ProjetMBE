const express=require('express');
const nodemailer = require("nodemailer");
const path = require('path')
const app=express();

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());
var port = 3000;

var smtpTransport = nodemailer.createTransport({
    service: "gmail",
    host: "smtp.gmail.com",
    auth: {
        user: "projetmbe@gmail.com",
        pass: "4f45e4r71d58e4"
    }
});


app.get('/',function(req,res){
    res.render('contact');
    });

    app.use(express.static(path.join(__dirname, 'public')));
    app.use(express.static(__dirname+'/public'));

    app.post('/send',function(req,res){
        const output= `
        <p>Vous avez une nouvelle demande de contact :</p>
        <ul>  
          <li>Nom : ${req.query.nom}</li>
          <li>Prénom : ${req.query.prenom}</li>
          <li>Adresse : ${req.query.adresse}</li> 
          <li>Email : ${req.query.mail}</li>
          <li>Téléphone : ${req.query.phone}</li>
          <li>Description du problème : ${req.query.messageperso}</li>
      `; 

      let mailOptions={
        from : '"Contact" <thisisatest@gmail.com>',
        to : 'projetmbe@gmail.com',
        subject : req.query.rubrique,
        text : 'hello ?',
        html:  output
     } 
         console.log(mailOptions);

         smtpTransport.sendMail(mailOptions, function(error, response){
         if(error){
         console.log(error);
         res.end("error");
         }else{
         console.log("Message sent: " + response.message);
         }
         });
        });

        
app.listen(3000,function(){
console.log("Server started on localhost:3000 please check if the server is working  ! ");
});